# Pairwise associations between binary questions - Year−adjusted GLMM with FDR−correction
# Mixed effect model can also adjust for random variables other than 'year'
# Requires a .csv populated with only binary answers, but can build in some other factors of interest

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(lme4)
  library(broom.mixed)
  library(ggplot2)
})

################################################################
#### 1) Set working dir, load the dataset, name variables ######
################################################################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs/SCOPS_Figure")
dat <- read.csv("SCOPS_OR5.csv", check.names = FALSE) %>%
  select(-Record) %>% # Remove unwanted variables here
  mutate(Year = as.factor(Year)) %>% #Set time or dates if needed
  mutate(across(-Year, ~ as.numeric(as.logical(.)))) #Set test variables to binary

# drop items already known to be structurally too sparse / non-overlapping - can also test for these on line 132 and insert later
#dat <- dat %>% select(-any_of(c("D_ZolvixBreakDose", "D_StartectBreakDose", "P_Q12_TreatAll", "A_Q22_Nematodirus", "D_Q17b_EverUsedStartect")))

vars <- setdiff(names(dat), "Year") #Set names of variables to be tested
var_pairs <- combn(vars, 2, simplify = FALSE) # Make a list of the variables to be compared - this will go across the data.


######################################################
#### 2) Pairwise GLMM with internal validation  ######
######################################################

# This function has a pre-built minimum n of 20 comparisons, and minimum years of 3, these can be altered based on the data tested.
# The function includes a number of tests to remove 
fit_pairwise_glmm <- function(outcome, predictor, df, min_n = 20, min_years = 3) {
  d <- df %>%
    select(Year, all_of(c(outcome, predictor))) %>%
    rename(y = all_of(outcome), x = all_of(predictor)) %>%
    filter(!is.na(y), !is.na(x), !is.na(Year)) %>%
    mutate(Year = droplevels(Year))
  
  n_used  <- nrow(d)
  n_years <- nlevels(d$Year)
  
  # minimum comparisons check
  if (n_used < min_n || length(unique(d$y)) < 2 || length(unique(d$x)) < 2) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "insufficient_data"))
  }
  
  # separation check (empty cell in 2x2 table)
  ct <- table(d$y, d$x)
  min_cell <- if (all(dim(ct) == c(2, 2))) min(ct) else 0
  if (min_cell == 0) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "separation"))
  }

  # minimum years covered check  
  if (n_years < min_years) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "insufficient_year_coverage"))
  }
  
  m <- tryCatch(
    glmer(y ~ x + (1 | Year), data = d, family = binomial,
          control = glmerControl(optimizer = "bobyqa")), #BOBYQA is the new best approach for mixed-model https://www.damtp.cam.ac.uk/user/na/NA_papers/NA2009_06.pdf
    error = function(e) NULL,
    warning = function(w) NULL   # treat convergence warnings as failure
  )
  
  # Convergence check
  if (is.null(m)) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "convergence_failure"))
  }
  
  fx <- tidy(m, effects = "fixed", conf.int = TRUE) %>% filter(term != "(Intercept)")
  
  tibble(
    outcome, predictor, n_used, n_years,
    OR = exp(fx$estimate), OR_low = exp(fx$conf.low), OR_high = exp(fx$conf.high),
    p_value = fx$p.value, flag_reason = NA_character_
  )
}

####################################################
#### 3) Running the GLMM for all comparisons  ######
####################################################

# Run across all pairs
results <- map_dfr(var_pairs, ~ fit_pairwise_glmm(.x[1], .x[2], df = dat))

# See flagged results
table(results$flag_reason) # See failure reasons and count.
round(prop.table(table(results$flag_reason, useNA = "ifany")) * 100, 1) #See proportion of failure

# FDR correction 
results <- results %>%
  mutate(flagged = !is.na(flag_reason)) %>% #Ignore flagged results
  group_by(flagged) %>%
  mutate(p_adj = if_else(flagged, NA_real_, p.adjust(p_value, method = "fdr"))) %>% #Can use other methods here if needed
  ungroup()

# Significance values at asterisks (for the ggplot)
results <- results %>%
  mutate(stars = case_when(
    is.na(p_adj)      ~ "",
    p_adj < 0.001      ~ "***",
    p_adj < 0.01       ~ "**",
    p_adj < 0.05       ~ "*",
    p_adj < 0.1        ~ ".",
    TRUE               ~ ""
  ))

###################################################
#### 4) Clean up the results - remove flags  ######
###################################################

valid_vars <- results %>%
  filter(!flagged) %>%
  select(outcome, predictor) %>%
  pivot_longer(everything(), values_to = "var") %>%
  distinct(var) %>%
  pull(var)

dropped_vars <- setdiff(vars, valid_vars)
if (length(dropped_vars) > 0) {
  message("Dropping vars with no usable comparisons: ", paste(dropped_vars, collapse = ", "))
}

results_clean <- results %>%
  filter(outcome %in% valid_vars, predictor %in% valid_vars)

#################################
#### 5) Outputs and Plots  ######
#################################

write.csv(results_clean, "pairwise_glmm_results_R.csv", row.names = FALSE) # Output table

# Make a plot for all significant values
plot_dat <- results_clean %>%
  filter(!flagged, p_adj < 0.1) %>%
  mutate(label = paste0(round(OR, 2), "\n", stars),
         logOR = log(OR))

# make symmetric for plotting
plot_dat_sym <- bind_rows(
  plot_dat %>% rename(var1 = outcome, var2 = predictor),
  plot_dat %>% rename(var1 = predictor, var2 = outcome)
)

# final_vars ordered for plot
final_vars <- c("SCOPS", "A_Q22_Nematodirus", "A_Q12_Refugia", "A_Q13_Worried", "A_Q14_Discuss",
                "A_Q15_Closed", "A_Q19_FEC", "A_Q22_Nematodirus", "A_Q24_Haemonchus",
                "A_Q4_Effective", "D_BZ_Used", "D_ML_Used", "D_MOX_Used", "D_LEV_Used",
                "D_AAD_Used", "D_Q17a_EverUsedZolvix", "P_Q2_RotateDrug",
                "P_Q7_TakingSteps", "P_Q10_TreatMoveDirty", "P_Q11_DiffDrugQuarantine",
                "P_Q11_QuarantineDose", "P_Q11_QuarantineYardOnTreatment",
                "P_Q11_QuarantineTurnOutDirtyPasture")
final_vars <- intersect(final_vars, valid_vars)  

# variable name -> display label
var_labels <- c(
  SCOPS                               = "SCOPS aware",
  A_Q12_Refugia                       = "Refugia aware",
  A_Q13_Worried                       = "Worried about AR",
  A_Q14_Discuss                       = "Discusses AR with vet",
  A_Q15_Closed                        = "Knows farms closed due to worms",
  A_Q19_FEC                           = "Performs FEC tests",
  A_Q22_Nematodirus                   = "SCOPS Nematodirus forecast aware",
  A_Q24_Haemonchus                    = "Had problems with H. contortus last year",
  A_Q4_Effective                      = "All Wormers Work Effectively",
  D_BZ_Used                           = "Used Benzimidazole this year",
  D_ML_Used                           = "Used Macrocyclic Lactone this year",
  D_MOX_Used                          = "Used Moxidectin this year",
  D_LEV_Used                          = "Used Levamisole this year",
  D_AAD_Used                          = "Used Monepantel (Zolvix) this year",
  D_Q17a_EverUsedZolvix               = "Ever Used Monepantel (Zolvix)",
  P_Q2_RotateDrug                     = "Rotates Drug Class",
  P_Q7_TakingSteps                    = "Taking Steps to Slow AR",
  P_Q10_TreatMoveDirty                = "Treats and Moves to Dirty Pasture",
  P_Q11_DiffDrugQuarantine            = "Different Drug for Quarantine",
  P_Q11_QuarantineDose                = "Quarantine Dose to Avoid Introduction of AR",
  P_Q11_QuarantineYardOnTreatment     = "Yards Quarantine Animals on Treatment",
  P_Q11_QuarantineTurnOutDirtyPasture = "Turns Out Quarantine to Dirty Pasture"
)

#Plot the data
ggplot(plot_dat_sym, aes(x = var1, y = var2, fill = logOR)) +
  geom_tile(color = "white") +
  geom_text(aes(label = label), size = 2) +
  scale_fill_gradient2(low = "red", mid = "white", high = "blue",
                       midpoint = 0, name = "log(OR)") +
  scale_x_discrete(limits = final_vars, labels = var_labels[final_vars]) +
  scale_y_discrete(limits = rev(final_vars), labels = var_labels[rev(final_vars)]) +
  theme_bw(base_size = 10) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
        panel.grid = element_blank(),
        legend.position="top") +
  labs(x = NULL, y = NULL)

ggsave("pairwise_heatmap.png", width = 12, height = 11, dpi = 300)




