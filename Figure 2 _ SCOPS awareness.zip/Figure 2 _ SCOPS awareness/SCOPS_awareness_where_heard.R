# Figure parts relating to SCOPS awareness
# Requires the related .csv 

install.packages('ggpubr')
library(ggpubr)
library(tidyverse)
library(readr)
library(readr)
library(dplyr)
library(stringr)
library(ggplot2)
library(scales)
library(forcats)

########################################
#### 1) SCOPS awareness over time ######
########################################

# Q18_SCOPS	Have you heard of the SCOPS initiative? Manually pulled from dataset
Year <- c(2007,2011,2013,2015,2017,2019,2023,2025)
PropYes <- c(40.6,59.2,51.2,62.9,73.1,60.7,78.3,81.1)
l <- lm(Year ~ PropYes)
summary(l) # Multiple R-squared:  0.8262,	Adjusted R-squared:  0.7973, F-statistic: 28.53 on 1 and 6 DF,  p-value: 0.001759

# Plot regression of SCOPS awareness over years
Heard <- ggplot(,aes(x = Year, y = PropYes))
a <- Heard + geom_point() + 
  geom_smooth(method = lm, formula = NULL, se = TRUE, position = "identity") +
  coord_cartesian(xlim = c(2007, 2025), ylim = c(0, 100))+
  scale_x_continuous(breaks=seq(2007, 2025, 2))+
  ylab("Heard of the SCOPS initiative (%)")+
  theme_bw()
a

##########################################
#### 2) Where did you hear of SCOPS ######
##########################################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs")

# Import data from specific .csv
df <- read_csv("SCOPS_Source.csv")
df_plot <- df %>%
  group_by(Category) %>%
  mutate(
    category_total = sum(Count, na.rm = TRUE),
    prop = Count / category_total
  ) %>%
  arrange(Category, desc(Count)) %>%
  mutate(y_pos = cumsum(prop) - 0.5 * prop) %>%
  ungroup()

df_plot <- df_plot %>%
  mutate(Category = fct_reorder(Category, category_total))

answer_order <- df_plot %>%
  group_by(Answer) %>%
  summarise(total = sum(Count), .groups = "drop") %>%
  arrange(desc(total)) %>%
  pull(Answer)

df_plot <- df_plot %>%
  mutate(Answer = factor(Answer, levels = answer_order))

# Plot Q18_SCOPS	Where did you heard about SCOPS?
ggplot(df_plot, aes(x = Category, y = Prop, fill = Answer)) +
  geom_col(color = "white", width = 0.85) +
  coord_flip() +
  labs(
    x = "Where did you hear about SCOPS?",
    y = "Responses (%)",
    fill = "Answer"
  ) +
  theme_bw()
