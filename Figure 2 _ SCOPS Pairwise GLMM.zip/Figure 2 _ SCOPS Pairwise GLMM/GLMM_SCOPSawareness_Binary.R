# Pairwise associations between SCOPS awareness and binary questions - Year−adjusted GLMM with FDR−correction
# Requires a .csv populated with only binary answers, but can build in some other factors of interest

suppressPackageStartupMessages({
  library(dplyr)
  library(purrr)
  library(lme4)
  library(broom.mixed)
  library(ggplot2)
})

################################################################
#### 1) Set working dir, load the dataset, name variables ######
################################################################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs/SCOPS_Figure")
dat <- read.csv("SCOPS_OR5.csv", check.names = FALSE) %>%
  select(-Record) %>% # Remove unwanted variables here
  mutate(Year = as.factor(Year)) %>% #Set time or dates if needed
  mutate(across(-Year, ~ as.numeric(as.logical(.)))) #Set test variables to binary

######################################################
#### 2) Pairwise GLMM with internal validation  ######
######################################################

# This function has a pre-built minimum n of 20 comparisons, and minimum years of 3, these can be altered based on the data tested.
# The function includes a number of tests to remove 
fit_pairwise_glmm <- function(outcome, predictor, df, min_n = 20, min_years = 2) {
  d <- df %>%
    select(Year, all_of(c(outcome, predictor))) %>%
    rename(y = all_of(outcome), x = all_of(predictor)) %>%
    filter(!is.na(y), !is.na(x), !is.na(Year)) %>%
    mutate(Year = droplevels(Year))
  
  n_used  <- nrow(d)
  n_years <- nlevels(d$Year)
  
  # minimum comparisons check
  if (n_used < min_n || length(unique(d$y)) < 2 || length(unique(d$x)) < 2) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "insufficient_data"))
  }
  
  # separation check (empty cell in 2x2 table)
  ct <- table(d$y, d$x)
  min_cell <- if (all(dim(ct) == c(2, 2))) min(ct) else 0
  if (min_cell == 0) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "separation"))
  }
  
  # minimum years covered check  
  if (n_years < min_years) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "insufficient_year_coverage"))
  }
  
  m <- tryCatch(
    glmer(y ~ x + (1 | Year), data = d, family = binomial,
          control = glmerControl(optimizer = "bobyqa")), #BOBYQA is the new best approach for mixed-model https://www.damtp.cam.ac.uk/user/na/NA_papers/NA2009_06.pdf
    error = function(e) NULL,
    warning = function(w) NULL   # treat convergence warnings as failure
  )
  
  # Convergence check
  if (is.null(m)) {
    return(tibble(outcome, predictor, n_used, n_years,
                  OR = NA, OR_low = NA, OR_high = NA, p_value = NA,
                  flag_reason = "convergence_failure"))
  }
  
  fx <- tidy(m, effects = "fixed", conf.int = TRUE) %>% filter(term != "(Intercept)")
  
  tibble(
    outcome, predictor, n_used, n_years,
    OR = exp(fx$estimate), OR_low = exp(fx$conf.low), OR_high = exp(fx$conf.high),
    p_value = fx$p.value, flag_reason = NA_character_
  )
}

outcomes <- setdiff(names(dat), c("Year", "SCOPS"))

##########################################
#### 2) Generate and clean results  ######
##########################################

scops_results <- map_dfr(outcomes, ~ fit_pairwise_glmm(outcome = .x, predictor = "SCOPS", df = dat))

# See flagged results
table(scops_results$flag_reason) # See failure reasons and count.
round(prop.table(table(scops_results$flag_reason, useNA = "ifany")) * 100, 1) #See proportion of failure

# FDR correction 
scops_results <- scops_results %>%
  mutate(flagged = !is.na(flag_reason)) %>% # Remove flagged results
  group_by(flagged) %>%
  mutate(p_adj = if_else(flagged, NA_real_, p.adjust(p_value, method = "fdr"))) %>% #Can use other methods here if needed
  ungroup()

# Significance values at asterisks (Not shown in the ggplot but could be added)
scops_results <- scops_results %>%
  mutate(stars = case_when(
    is.na(p_adj)      ~ "",
    p_adj < 0.001      ~ "***",
    p_adj < 0.01       ~ "**",
    p_adj < 0.05       ~ "*",
    p_adj < 0.1        ~ ".",
    TRUE               ~ ""
  ))




#################################
#### 5) Outputs and Plots  ######
#################################

write.csv(scops_results, "glmm_scops_results.csv", row.names = FALSE)

print(scops_results, n = Inf)

plot_dat <- scops_results %>%
  filter(!flagged) %>%
  mutate(
    p_label = case_when(
      p_value < 0.001 ~ "p < 0.001",
      TRUE             ~ paste0("p = ", formatC(p_value, digits = 3, format = "f"))
    ),
    outcome = factor(outcome, levels = rev(sort(unique(outcome))))
  )

# variable name -> display label
var_labels <- c(
  SCOPS                               = "SCOPS aware",
  A_Q12_Refugia                       = "Refugia aware",
  A_Q13_Worried                       = "Worried about AR",
  A_Q14_Discuss                       = "Discusses AR with vet",
  A_Q15_Closed                        = "Knows farms closed due to worms",
  A_Q19_FEC                           = "Performs FEC tests",
  A_Q22_Nematodirus                   = "SCOPS Nematodirus forecast aware",
  A_Q24_Haemonchus                    = "Had problems with H. contortus last year",
  A_Q4_Effective                      = "All Wormers Work Effectively",
  D_BZ_Used                           = "Used Benzimidazole this year",
  D_ML_Used                           = "Used Macrocyclic Lactone this year",
  D_MOX_Used                          = "Used Moxidectin this year",
  D_LEV_Used                          = "Used Levamisole this year",
  D_AAD_Used                          = "Used Monepantel this year",
  D_Q17a_EverUsedZolvix               = "Ever Used Monepantel",
  D_Q17b_EverUsedStartect             = "Ever Used Startect",
  D_ZolvixBreakDose                   = "Used Monepantel as a break dose",
  D_StartectBreakDose                 = "Used Startect as a break dose",
  P_Q12_TreatAll                      = "Dose all lambs in flock",
  P_Q2_RotateDrug                     = "Rotates Drug Class",
  P_Q7_TakingSteps                    = "Taking Steps to Slow AR",
  P_Q10_TreatMoveDirty                = "Treats and Moves to Dirty Pasture",
  P_Q11_DiffDrugQuarantine            = "Different Drug for Quarantine",
  P_Q11_QuarantineDose                = "Quarantine Dose to Avoid Introduction of AR",
  P_Q11_QuarantineYardOnTreatment     = "Yards Quarantine Animals on Treatment",
  P_Q11_QuarantineTurnOutDirtyPasture = "Turns Out Quarantine to Dirty Pasture"
)

# Sort plot by section
section_lookup <- c(
  A_Q12_Refugia          = "Awareness of parasites and resistance",
  A_Q13_Worried           = "Awareness of parasites and resistance",
  A_Q14_Discuss           = "Awareness of parasites and resistance",
  A_Q15_Closed            = "Awareness of parasites and resistance",
  A_Q19_FEC               = "Awareness of parasites and resistance",
  A_Q22_Nematodirus       = "Awareness of parasites and resistance",
  A_Q4_Effective          = "Awareness of parasites and resistance",
  A_Q24_Haemonchus        = "Awareness of parasites and resistance",
  
  D_BZ_Used               = "Anthelmintic use",
  D_ML_Used               = "Anthelmintic use",
  D_MOX_Used              = "Anthelmintic use",
  D_LEV_Used              = "Anthelmintic use",
  D_AAD_Used              = "Anthelmintic use",
  D_Q17a_EverUsedZolvix   = "Anthelmintic use",
  D_Q17b_EverUsedStartect = "Anthelmintic use",
  D_ZolvixBreakDose       = "Anthelmintic use",
  D_StartectBreakDose     = "Anthelmintic use",
  
  P_Q12_TreatAll                      = "SCOPS principles",
  P_Q2_RotateDrug                     = "SCOPS principles",
  P_Q7_TakingSteps                    = "SCOPS principles",
  P_Q10_TreatMoveDirty                = "SCOPS principles",
  P_Q11_DiffDrugQuarantine            = "SCOPS principles",
  P_Q11_QuarantineDose                = "SCOPS principles",
  P_Q11_QuarantineYardOnTreatment     = "SCOPS principles",
  P_Q11_QuarantineTurnOutDirtyPasture = "SCOPS principles"
)

# Order plot by OR and by section
plot_dat <- plot_dat %>%
  mutate(section = section_lookup[as.character(outcome)],
         section = factor(section, levels = c("Awareness of parasites and resistance",
                                              "Anthelmintic use", "SCOPS principles")))
plot_dat <- plot_dat %>%
  arrange(section, desc(OR)) %>%
  mutate(outcome = factor(outcome, levels = rev(unique(outcome))))

# Plot
ggplot(plot_dat, aes(x = OR, y = outcome)) +
  geom_vline(xintercept = 1, linetype = "dashed") +
  geom_pointrange(aes(xmin = OR_low, xmax = OR_high)) +
  geom_text(aes(x = 15, label = p_label), hjust = 0, size = 3) +
  facet_grid(section ~ ., scales = "free_y", space = "free", switch = "y") +
  scale_x_log10(limits = c(0.05, 60), breaks = c(0.1, 1, 10)) +
  scale_y_discrete(labels = var_labels) +
  coord_cartesian(clip = "off") +
  labs(x = "Odds Ratio (95% CI, log scale)", y = NULL) +
  theme_minimal(base_size = 11) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    strip.placement = "outside",
    strip.text.y.left = element_text(angle = 0, face = "bold"),
    plot.margin = margin(5.5, 70, 5.5, 5.5)
  )
