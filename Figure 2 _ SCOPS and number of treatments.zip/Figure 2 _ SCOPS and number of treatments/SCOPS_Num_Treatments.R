# Figure parts relating to SCOPS and number of treatments given
# Requires the related .csv 

install.packages('coin')
library(coin)
library(tidyverse)
library(readr)
library(lubridate)
library(rstatix)
library(scales)

########################
#### 1) Load data ######
########################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs/SCOPS_Figure")
Trt <- read_csv("SCOPS_Num_Treatments.csv")
Trt <- Trt %>% drop_na(Q18_SCOPS)
Trt$Year <- as.numeric(Trt$Year)
Trt$lamb_cat <- factor(Trt$lamb_cat, levels = c("Never", "Selectively", "1-2 times", "3-5 times", ">5 times", "Periodically"))
Trt$ewe_cat <- factor(Trt$ewe_cat, levels = c("Never", "Selectively", "1-2 times", "3-5 times", ">5 times"))
lapply(Trt, class)
colnames(Trt)

##############################
#### 2) Lamb treatments ######
##############################

# Looking at differences in responses between SCOPS yes and no farms for treatment amounts - LAMBS
tab_lamb <- table(Trt$Q18_SCOPS, Trt$lamb_cat)
tab_lamb
chisq <- chisq.test(tab_lamb)
chisq$stdres
fisher.test(tab_lamb, simulate.p.value = TRUE)
cramer_v(tab_lamb)

# Plot for lamb treatments
Trt_lamb <- Trt 
Trt_lamb$lamb_cat <- factor(Trt_lamb$lamb_cat, levels = c("Never", "Selectively", "1-2 times", "3-5 times", ">5 times", "Periodically"))
Trt_lamb <- Trt_lamb %>% drop_na(lamb_cat)

Trt_lamb %>%
  mutate(SCOPS = ifelse(Q18_SCOPS, "TRUE", "FALSE")) %>%
  count(SCOPS, lamb_cat) %>%
  complete(
    SCOPS,
    lamb_cat,
    fill = list(n = 0)
  ) %>%                      # ← forces missing TRUE/FALSE × category rows
  group_by(SCOPS) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  ggplot(aes(x = lamb_cat, y = pct, fill = SCOPS)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.75) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  scale_x_discrete(drop = FALSE) +
  labs(
    title = "Lambs",
    x = NULL,
    y = "Responses (%)",
    fill = "Have you heard of SCOPS?") + 
  theme_bw() +
  theme(legend.position="top")

#############################
#### 2) Ewe treatments ######
#############################

# Looking at differences in responses between SCOPS yes and no farms for treatment amounts - EWES
tab_ewe <- table(Trt$Q18_SCOPS, Trt$ewe_cat)
tab_ewe
chisq <- chisq.test(tab_ewe)
chisq$stdres
fisher.test(tab_ewe, simulate.p.value = TRUE)
cramer_v(tab_ewe)

# Plot for number of ewe treatments
Trt_ewe <- Trt 
Trt_ewe$ewe_cat <- factor(Trt_ewe$ewe_cat, levels = c("Never", "Selectively", "1-2 times", "3-5 times", ">5 times", "Periodically"))
Trt_ewe <- Trt_ewe %>% drop_na(ewe_cat)

Trt_ewe %>%
  mutate(SCOPS = ifelse(Q18_SCOPS, "TRUE", "FALSE")) %>%
  count(SCOPS, ewe_cat) %>%
  complete(
    SCOPS,
    ewe_cat,
    fill = list(n = 0)
  ) %>%                      # ← forces missing TRUE/FALSE × category rows
  group_by(SCOPS) %>%
  mutate(pct = n / sum(n)) %>%
  ungroup() %>%
  ggplot(aes(x = ewe_cat, y = pct, fill = SCOPS)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.75) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  scale_x_discrete(drop = FALSE) +
  labs(
    title = "Ewes",
    x = NULL,
    y = "Responses (%)",
    fill = "Q18_SCOPS") +
  theme_bw() +
  theme(legend.position="top")
