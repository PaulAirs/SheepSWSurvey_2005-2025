# Figure to look at farm size and SCOPS-awareness
# Requires the relevant .csv

install.packages('rstatix') 
install.packages('coin')
library(rstatix)
library(coin)
library(tidyverse)
library(readr)

################################################
#### 1) Set working dir, load the dataset ######
################################################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs/SCOPS_Figure")
Farmsize_SCOPS <- read_csv("Farmsize_SCOPS.csv")

Farmsize_SCOPS <- na.omit(Farmsize_SCOPS)
Farmsize_SCOPS$Q1_Num <- as.numeric(Farmsize_SCOPS$Q1_Num)
Farmsize_SCOPS$Q18_SCOPS <- factor(Farmsize_SCOPS$Q18_SCOPS)

# Stat summaries - n - median - IQR - mean - SD
Farmsize_SCOPS %>%
  dplyr::group_by(Q18_SCOPS) %>%
  dplyr::summarise(
    n = dplyr::n(),
    median = median(Q1_Num, na.rm = TRUE),
    IQR = IQR(Q1_Num, na.rm = TRUE),
    mean = mean(Q1_Num, na.rm = TRUE),
    sd = sd(Q1_Num, na.rm = TRUE),
    .groups = "drop"
  )

##########################################
#### 2) Statistical tests and plots ######
##########################################

# Tests for normality and differences
shapiro.test(Farmsize_SCOPS$Q1_Num)

wilcox.test(Q1_Num ~ Q18_SCOPS, data = Farmsize_SCOPS, method = "two.sided")

# Violin plot
ggplot(Farmsize_SCOPS, aes(x = Q18_SCOPS, y = Q1_Num)) +
  geom_violin() +
  stat_summary(fun.data="mean_sdl",  fun.args = list(mult=1), 
               geom="pointrange", color = "black") +
  scale_y_log10() +
  theme_bw()




################################
# UNUSED ADDITIONAL STATISTICS #
################################

# Box plot
ggplot(Farmsize_SCOPS,
       aes(x = Q18_SCOPS, y = Q1_Num)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(width = 0.15, alpha = 0.3) +
  scale_y_continuous(trans = "log10") +
  theme_minimal() +
  labs(y = "Farm size (log10 scale)")

# Histogram
ggplot(Farmsize_SCOPS, aes(x = Q1_Num)) +
  geom_histogram(aes(y = after_stat(density)),
                 bins = 30,
                 fill = "blue",
                 colour = "black") +
  facet_wrap(~ Q18_SCOPS) +
  theme_minimal()

cohens_d(Q1_Num ~ Q18_SCOPS,
         data = Farmsize_SCOPS)

median_test(Q1_Num ~ Q18_SCOPS,
            data = Farmsize_SCOPS,
            distribution = "exact")


# ANOVA
model=lm( Farmsize_SCOPS$Q1_Num ~ Farmsize_SCOPS$Q18_SCOPS)
ANOVA=aov(model)
summary(model)
summary(ANOVA)

# Tukey test to study each pair of treatment
TUKEY <- TukeyHSD(x=ANOVA, 'Farmsize_SCOPS$Q18_SCOPS', conf.level=0.95)
TUKEY
