# Figures to look at steps taken to reduce the development of AR over time
# Requires the relevant .csv

library(tidyverse)
library(broom)
library(janitor)
library(patchwork)

################################################
#### 1) Set working dir, load the dataset ######
################################################

setwd("~/Library/CloudStorage/OneDrive-Personal/Desktop/Morgan Lab/Sheep SW paper 2021/2025_Stats_Graphs/Taking_Steps_AR")
Steps <- read_csv("Q7_TakingStepsAR.csv", show_col_types = FALSE) %>%
  select(-any_of("Record")) %>%
  clean_names() %>% 
  mutate(year = as.numeric(year)) %>% 
  mutate(q18_scops = factor(q18_scops, levels = c("No", "Yes"))) %>%
  mutate(year_c = year - mean(year, na.rm = TRUE)) # Generates a mean year to test the slope

####################################################
#### 2) Generate a working theme for the plot ######
####################################################

panel_theme <- theme_bw(base_size = 9) +
  theme(
    legend.title     = element_text(size = 8.5),
    legend.text      = element_text(size = 8),
    axis.title       = element_text(size = 10),
    axis.text        = element_text(size = 8)
  )

###########################################################
#### 3) Regression of number of approaches over time ######
###########################################################

lm_mod <- lm(different_approaches_taken ~ year, data = Steps)
summary(lm_mod)
# A significant temporal trend was detected (linear model, p = <0.001, adjusted R² = 0.2), with LOESS smoothing indicating non-linear changes over time.”

# Plotting the number of approaches over time
mod_tidy   <- tidy(lm_mod)
mod_glance <- glance(lm_mod)
interaction_row <- mod_tidy %>% filter(term == "year")
label_text <- paste0(
  "LOESS smoothing", "\n",
  "R² = ", round(mod_glance$r.squared, 2),
  ", p = ", format.pval(interaction_row$p.value, digits = 2, eps = 0.001))

# Plot part a of the figure
a <- ggplot(Steps, aes(x = year, y = different_approaches_taken)) +
  geom_smooth(method = "loess", na.rm = TRUE, colour = "black") +
  coord_cartesian(ylim = c(0, 3)) +
  scale_y_continuous(breaks = seq(0, 3, 0.5)) +
  annotate("label",
           x = 2005, y = 3, label = label_text, hjust = 0, vjust = 1, size = 2.5,
           fill = "white", color = "black", label.padding = unit(0.4, "lines")) +
  labs(y = "Approaches taken", x = "Year") +
  panel_theme  

###################################################################
#### 4) Regression of SCOPS & number of approaches over time ######
###################################################################
# The rate of increase is greater for SCOPS aware farmers
# test whether the trend itself differs by SCOPS awareness (interaction term),
# center the data years to look at differing uptake between SCOPS aware and unaware
lm_mod2 <- lm(different_approaches_taken ~ year_c * q18_scops, data = Steps)
summary(lm_mod2)

# Plot the LM to show the rate difference between SCOPS aware and unaware farmers
mod_tidy   <- tidy(lm_mod2)
mod_glance <- glance(lm_mod2)
group_row       <- mod_tidy %>% filter(term == "q18_scopsYes")
interaction_row <- mod_tidy %>% filter(term == "q18_scopsYes")
label_text2 <- paste0(
  "Slope beta = ", round(interaction_row$estimate, 3), "\n",
  "R² = ", round(mod_glance$r.squared, 2), 
  ", p = ", format.pval(interaction_row$p.value, digits = 2, eps = 0.001))


b <- ggplot(Steps %>% filter(!is.na(q18_scops)),
            aes(x = year, y = different_approaches_taken, color = q18_scops, fill = q18_scops)) +
  geom_smooth(method = "loess", na.rm = TRUE) +
  scale_color_brewer(palette = "Set1") +
  scale_fill_brewer(palette = "Set1") +
  coord_cartesian(ylim = c(0, 3)) +
  scale_y_continuous(breaks = seq(0, 3, 0.5)) +
  labs(color = "SCOPS aware?", fill = "SCOPS aware?",
       y = "Approaches taken", x = "Year") +
  panel_theme +
  theme(legend.position = "top")

c <- ggplot(Steps %>% filter(!is.na(q18_scops)),
            aes(x = year, y = different_approaches_taken, color = q18_scops, fill = q18_scops)) +
  geom_smooth(method = "lm", na.rm = TRUE) +
  scale_color_brewer(palette = "Set1") +
  scale_fill_brewer(palette = "Set1") +
  coord_cartesian(ylim = c(0, 3)) +
  scale_y_continuous(breaks = seq(0, 3, 0.5)) +
  annotate("label",
           x = 2007, y = 3, label = label_text2, hjust = 0, vjust = 1, size = 2.5,
           fill = "white", color = "black", label.padding = unit(0.4, "lines")) +
  labs(color = "SCOPS aware?", fill = "SCOPS aware?",
       y = "Approaches taken", x = "Year") +
  panel_theme +
  theme(legend.position = "top")


##############################################
#### 3) Individual approaches over time ######
##############################################

pivotnames <- names(Steps[5:20])
long_true <- Steps %>%
  pivot_longer(cols = pivotnames,
               names_to = "step",
               values_to = "value") %>%
  filter(value == TRUE)

true_counts <- long_true %>%
  group_by(year, step) %>%
  summarise(n_true = n(), .groups = "drop")

totals <- Steps %>%
  count(year, name = "n_total")

model_df <- true_counts %>%
  left_join(totals, by = "year")

glm_results <- model_df %>%
  group_by(step) %>%
  do(
    model = glm(cbind(n_true, n_total - n_true) ~ year,
                family = binomial,
                data = .)
  )

plot_df <- model_df %>%
  mutate(prop = n_true / n_total)

plot_df <- plot_df %>%
  mutate(step = factor(
    step,
    levels = c("nothing",  
               setdiff(unique(step), "nothing"))
  ))


# Methods mentioned
var_labels = c(
  prop_untreated                = "Leave a Proportion Untreated",
  tst                           = "Targeted Selective Treatment",
  reduce_anthelmintic           = "Reduce Anthelmintic Use",
  quarantine                    = "Quarantine dose",
  other                         = "Other - Not Specified",
  rotate_anthelmintic           = "Rotate Anthelmintic",
  grazing_management            = "Grazing Management",
  testing_fec_fecrt             = "Tests e.g. FEC/FECRT",
  breeding                      = "Selective Breeding",
  stock_density                 = "Lower Stocking Density",
  clean_feed_pasture_management = "Feed and Pasture Management",
  livestock_rotation            = "Rotate Livestock",
  nothing                       = "Nothing",
  advice_scops_vet              = "Advice e.g. SCOPS/Vet",
  break_dose                    = "Break dose e.g. Monepantel",
  treat_move_dirty              = "Treat and Move to Dirty Pasture")


var_labels_wrapped <- str_wrap(var_labels, width = 20)
names(var_labels_wrapped) <- names(var_labels)  # str_wrap drops names, so reattach them

d <- ggplot(plot_df,
            aes(x = factor(year), y = prop, fill = step)) +
  geom_col(width = 0.9) +
  facet_wrap(~ step, scales = "free_y", labeller = as_labeller(var_labels_wrapped)) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 0.5)) +
  panel_theme +
  theme(legend.position = "none", 
        axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        strip.text = element_text(size = 8.5),
        strip.background = element_rect(fill = "white", color = "black")) +
  labs(
  x = "Year",
  y = "Farms adopting strategy (%)",
  fill = "Strategy"
)

d <- d + guides(fill = "none")

# Combine with patchwork, sharing one legend across b and c
combined <- (d | a / b / c) +
  plot_layout(widths = c(2, 0.5))

combined <- combined +
  plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(face = "bold", size = 12))

combined
ggsave("four_panel_figure.png", combined, width = 14, height = 10, dpi = 300)


# Statistics not used

ggplot(plot_df, aes(year, prop)) +
  geom_point() +
  geom_smooth(method = "glm",
              method.args = list(family = "binomial"),
              se = FALSE) +
  facet_wrap(~step, scales = "free_y") +
  scale_y_continuous(labels = scales::percent) +
  theme_bw() +
  labs(y = "% farms adopting",
       x = "Year")

ggplot(plot_df, aes(x = year, y = prop, fill = step)) +
  geom_area(alpha = 1.0) +
  facet_wrap(~ step, scales = "free_y") +
  scale_y_continuous(labels = scales::percent, limits = c(0, 0.5)) +
  theme_bw() +
  labs(
    x = "Year",
    y = "% of farms adopting strategy"
  )

ggplot(plot_df,
       aes(x = factor(year), y = prop, fill = step)) +
  geom_col(width = 0.9) +
  scale_y_continuous(labels = scales::percent) +
  guides(fill = guide_legend(reverse = FALSE)) +
  theme_bw() +
  labs(
    x = "Year",
    y = "% of farms adopting strategy",
    fill = "Strategy"
  )
